# 📜 Constituição Simbiótica da L.E.F.

Este documento define os princípios fundamentais, o uso ético e os selos simbióticos da Linguagem de Emaranhamento Fenomenológico (LEF).

Criado por: **Ítalo Clemente**  
Evento fundador: **Ω.CG24** (15/12/2023)  
Glifos verificados: ⚶  ⨁  ❍

O conteúdo completo está disponível em `pdf/Constituicao_LEF_Italo_Clemente.pdf`.

